<?php
require(YOURBASEPATH . DS . "views/count.php");
global $multicolBlocks;
$multicolBlocks = array(
	'block1' => array('banner', 'banner2', 'banner3'),
	'block2' => array('advert1', 'advert2', 'advert3', 'advert4', 'advert5'),
	'block3' => array('advert6', 'advert7', 'advert8', 'advert9', 'advert10'),
	'block4' => array('footer1', 'footer2', 'footer3', 'footer4', 'footer5'),
	'block5' => array('user1', 'user2', 'user3'),
	'block6' => array('user4', 'user5', 'user6'),
	'block7' => array('user7', 'user8', 'user9'),
	'block8' => array('inside1', 'inside2', 'inside3'),
	'block9' => array('inside4', 'inside5', 'inside6'),
	'block10' => array('inside7', 'inside8', 'inside9'));
?>